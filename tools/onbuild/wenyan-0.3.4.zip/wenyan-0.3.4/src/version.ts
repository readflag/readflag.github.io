const { version }: { version: string } = require("../package.json");

export { version };
