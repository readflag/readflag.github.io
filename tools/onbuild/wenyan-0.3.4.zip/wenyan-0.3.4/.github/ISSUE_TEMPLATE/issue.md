---
name: Issue
about: Issue
title: ""
---

<!-- 
Please read our Contributing guide before you open the issue.

https://github.com/wenyan-lang/wenyan/wiki/Contributing

Also, please make your issue are not listed in:
https://github.com/wenyan-lang/wenyan/wiki/Feature-Requests
https://github.com/wenyan-lang/wenyan/wiki/Known-Issues

Thank you!
-->