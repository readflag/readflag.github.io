# Contributing

Please check out the contributing guide on [wiki](https://github.com/wenyan-lang/wenyan/wiki/Contributing)