console.log(Math.PI)
console.log(JSON.stringify(Object.prototype))