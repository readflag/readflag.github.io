function main() {
  console.log("hello world!");
  var a = 5;
  var b = a + 5;
  if (b >= 10) {
    console.log('100');
  } else {
    console.log('99');
  }
}

main();