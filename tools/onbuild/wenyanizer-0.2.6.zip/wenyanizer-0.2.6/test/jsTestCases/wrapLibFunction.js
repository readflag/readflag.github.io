const func = Object.prototype.toString;
console.log(func(1));
const b = [];
console.log(Object.prototype.toString.call(b));
console.log(Math.sin(2));
console.log(Math.sin(99));