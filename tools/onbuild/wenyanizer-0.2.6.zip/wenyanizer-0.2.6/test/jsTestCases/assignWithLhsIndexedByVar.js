var a = {b: 2};
var c = 'b';
a[c] = 3;
const s = 'a';
var d = a[s]
console.log(a['b'], a[c]);