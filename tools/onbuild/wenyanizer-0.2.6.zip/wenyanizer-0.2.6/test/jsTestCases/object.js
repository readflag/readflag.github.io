var a = {
  a: '213',
  '烈日': 231
};

console.log(a)
console.log(a.a)
console.log(a['烈日'])