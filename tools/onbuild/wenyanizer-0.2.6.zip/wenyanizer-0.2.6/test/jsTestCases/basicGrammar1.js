console.log(2,3,3,4,5);
var a = 0;
var b = (a + 10) * 5;
console.log(b);
console.log(8 + b);