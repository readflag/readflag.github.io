var a = {};
a.b = 123;
