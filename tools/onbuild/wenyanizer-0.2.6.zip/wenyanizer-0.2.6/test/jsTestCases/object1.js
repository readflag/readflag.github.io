var a = {
  b: {
    c: {
      d: {
        e: 10
      }
    }
  }
};

console.log(a.b.c.d.e);